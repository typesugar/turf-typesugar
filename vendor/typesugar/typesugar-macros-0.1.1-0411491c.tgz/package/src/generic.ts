/**
 * Generic Programming for Typeclass Derivation
 *
 * This module provides structural representations (Product/Sum) that enable
 * "derive once, use everywhere" typeclass instances.
 *
 * ## Overview
 *
 * Instead of generating Show/Eq/etc. code for every type, we:
 * 1. Define Show/Eq/etc. for Product<Fields> and Sum<Variants> ONCE
 * 2. Auto-derive Generic<T> that converts T <-> its structural form
 * 3. @derive(Show) just bridges through the generic representation
 *
 * ## Example
 *
 * ```typescript
 * // Define your type
 * interface Point { x: number; y: number; }
 *
 * // @derive(Generic) creates:
 * // - Type-level: type PointRep = Product<[["x", number], ["y", number]]>
 * // - to/from functions for runtime conversion
 *
 * // @derive(Show) then just uses:
 * // show(point) → showProduct.show(Generic.to(point))
 * ```
 *
 * ## Key Types
 *
 * - `Product<Fields>` - Structural representation of records/structs
 * - `Sum<Variants>` - Structural representation of discriminated unions
 * - `Generic<T, Rep>` - Typeclass for converting T <-> Rep
 *
 * @packageDocumentation
 */

import * as ts from "typescript";
import { defineAttributeMacro, defineDeriveMacro, globalRegistry } from "@typesugar/core";
import { MacroContext, DeriveFieldInfo, DeriveVariantInfo } from "@typesugar/core";
import { tryExtractSumType } from "./typeclass.js";

// ============================================================================
// Structural Representation Types
// ============================================================================

/**
 * A field in a product type: [name, value]
 */
export type Field<Name extends string, Value> = readonly [Name, Value];

/**
 * Product type - represents structs/records as a tuple of fields.
 *
 * ```typescript
 * // Point { x: number, y: number } becomes:
 * type PointRep = Product<[Field<"x", number>, Field<"y", number>]>;
 * ```
 */
export type Product<Fields extends readonly Field<string, unknown>[]> = {
  readonly _tag: "Product";
  readonly fields: { [K in keyof Fields]: Fields[K][1] };
  readonly names: { [K in keyof Fields]: Fields[K][0] };
};

/**
 * A variant in a sum type: [tag, payload]
 */
export type Variant<Tag extends string, Payload> = readonly [Tag, Payload];

/**
 * Sum type - represents discriminated unions.
 *
 * ```typescript
 * // type Shape = Circle | Rectangle becomes:
 * type ShapeRep = Sum<[Variant<"circle", Circle>, Variant<"rectangle", Rectangle>]>;
 * ```
 */
export type Sum<Variants extends readonly Variant<string, unknown>[]> = {
  readonly _tag: "Sum";
  readonly discriminant: string;
  readonly value: Variants[number];
};

/**
 * Type-level helper to extract the representation type for a given type.
 * This is populated by @derive(Generic).
 */
export type Rep<T> = T extends { __rep__: infer R } ? R : never;

// ============================================================================
// Generic Typeclass
// ============================================================================

/**
 * Generic typeclass - converts between a type and its structural representation.
 *
 * This is the key abstraction: once we can convert T <-> Product/Sum,
 * any typeclass defined on Product/Sum works for T automatically.
 */
export interface Generic<T, R> {
  /** Convert from the original type to its generic representation */
  to(value: T): R;
  /** Convert from the generic representation back to the original type */
  from(rep: R): T;
}

// Registry for Generic instances
const genericRegistry = new Map<string, Generic<unknown, unknown>>();

export function registerGeneric<T, R>(typeName: string, instance: Generic<T, R>): void {
  genericRegistry.set(typeName, instance as Generic<unknown, unknown>);
}

export function getGeneric<T, R>(typeName: string): Generic<T, R> | undefined {
  return genericRegistry.get(typeName) as Generic<T, R> | undefined;
}

// ============================================================================
// Product/Sum Typeclass Instances
// ============================================================================

/**
 * Show for Product types - works for ANY product!
 */
export function showProduct<Fields extends readonly Field<string, unknown>[]>(
  fieldShows: { [K in keyof Fields]: { show: (a: Fields[K][1]) => string } },
  fieldNames: { [K in keyof Fields]: Fields[K][0] }
): { show: (p: Product<Fields>) => string } {
  return {
    show: (p: Product<Fields>): string => {
      const parts: string[] = [];
      for (let i = 0; i < fieldNames.length; i++) {
        const name = fieldNames[i];
        const value = p.fields[i];
        const showFn = fieldShows[i];
        parts.push(`${name} = ${showFn.show(value)}`);
      }
      return `(${parts.join(", ")})`;
    },
  };
}

/**
 * Show for Sum types - works for ANY sum!
 */
export function showSum<Variants extends readonly Variant<string, unknown>[]>(
  variantShows: {
    [K in keyof Variants]: { show: (a: Variants[K][1]) => string };
  },
  variantTags: { [K in keyof Variants]: Variants[K][0] }
): { show: (s: Sum<Variants>) => string } {
  return {
    show: (s: Sum<Variants>): string => {
      const [tag, value] = s.value;
      const idx = variantTags.indexOf(tag as Variants[number][0]);
      if (idx >= 0) {
        const showFn = variantShows[idx];
        return `${tag}(${showFn.show(value)})`;
      }
      return `Unknown(${tag})`;
    },
  };
}

/**
 * Eq for Product types
 */
export function eqProduct<Fields extends readonly Field<string, unknown>[]>(fieldEqs: {
  [K in keyof Fields]: { eq: (a: Fields[K][1], b: Fields[K][1]) => boolean };
}): { eq: (a: Product<Fields>, b: Product<Fields>) => boolean } {
  return {
    eq: (a: Product<Fields>, b: Product<Fields>): boolean => {
      for (let i = 0; i < fieldEqs.length; i++) {
        if (!fieldEqs[i].eq(a.fields[i], b.fields[i])) {
          return false;
        }
      }
      return true;
    },
  };
}

/**
 * Eq for Sum types
 */
export function eqSum<Variants extends readonly Variant<string, unknown>[]>(
  variantEqs: {
    [K in keyof Variants]: {
      eq: (a: Variants[K][1], b: Variants[K][1]) => boolean;
    };
  },
  variantTags: { [K in keyof Variants]: Variants[K][0] }
): { eq: (a: Sum<Variants>, b: Sum<Variants>) => boolean } {
  return {
    eq: (a: Sum<Variants>, b: Sum<Variants>): boolean => {
      const [tagA, valueA] = a.value;
      const [tagB, valueB] = b.value;
      if (tagA !== tagB) return false;
      const idx = variantTags.indexOf(tagA as Variants[number][0]);
      if (idx >= 0) {
        return variantEqs[idx].eq(valueA, valueB);
      }
      return false;
    },
  };
}

/**
 * Ord for Product types (lexicographic)
 */
export function ordProduct<Fields extends readonly Field<string, unknown>[]>(fieldOrds: {
  [K in keyof Fields]: {
    compare: (a: Fields[K][1], b: Fields[K][1]) => number;
  };
}): { compare: (a: Product<Fields>, b: Product<Fields>) => number } {
  return {
    compare: (a: Product<Fields>, b: Product<Fields>): number => {
      for (let i = 0; i < fieldOrds.length; i++) {
        const c = fieldOrds[i].compare(a.fields[i], b.fields[i]);
        if (c !== 0) return c;
      }
      return 0;
    },
  };
}

/**
 * Hash for Product types
 */
export function hashProduct<Fields extends readonly Field<string, unknown>[]>(fieldHashes: {
  [K in keyof Fields]: { hash: (a: Fields[K][1]) => number };
}): { hash: (a: Product<Fields>) => number } {
  return {
    hash: (a: Product<Fields>): number => {
      let hash = 0;
      for (let i = 0; i < fieldHashes.length; i++) {
        hash = ((hash << 5) + hash) ^ fieldHashes[i].hash(a.fields[i]);
      }
      return hash >>> 0;
    },
  };
}

// ============================================================================
// Primitive Generic Instances (for recursion base cases)
// ============================================================================

// Primitives are their own representation — identity to/from
registerGeneric("number", { to: (n: number) => n, from: (n: number) => n });
registerGeneric("string", { to: (s: string) => s, from: (s: string) => s });
registerGeneric("boolean", { to: (b: boolean) => b, from: (b: boolean) => b });

// ============================================================================
// @derive(Generic) - Auto-derive Generic instance for a type
// ============================================================================

/**
 * Structural type mirror — analogous to Scala 3's Mirror.ProductOf / Mirror.SumOf.
 *
 * Stores the structural representation of a type for use by typeclass derivation.
 * - `fieldNames` ≈ `MirroredElemLabels`
 * - `fieldTypes` ≈ `MirroredElemTypes`
 * - `kind` ≈ `Mirror.Product` vs `Mirror.Sum`
 */
export interface GenericMeta {
  readonly kind: "product" | "sum" | "primitive";
  readonly discriminant?: string;
  readonly variants?: Array<{ tag: string; typeName: string }>;
  readonly fieldNames?: string[];
  readonly fieldTypes?: string[];
}

const genericMetaRegistry = new Map<string, GenericMeta>();

export function getGenericMeta(typeName: string): GenericMeta | undefined {
  return genericMetaRegistry.get(typeName);
}

export function registerGenericMeta(typeName: string, meta: GenericMeta): void {
  genericMetaRegistry.set(typeName, meta);
}

export const genericDerive = defineAttributeMacro({
  name: "Generic",
  module: "typesugar",
  description: "Derive Generic instance for structural programming",
  validTargets: ["interface", "class", "type"],

  expand(
    ctx: MacroContext,
    _decorator: ts.Decorator,
    target: ts.Declaration,
    _args: readonly ts.Expression[]
  ): ts.Node | ts.Node[] {
    if (
      !ts.isInterfaceDeclaration(target) &&
      !ts.isClassDeclaration(target) &&
      !ts.isTypeAliasDeclaration(target)
    ) {
      ctx.reportError(target, "@derive(Generic) requires interface, class, or type alias");
      return target;
    }
    return [target, ...expandGeneric(ctx, target)];
  },
});

/**
 * `@derive(Generic)` — the same expansion as the `@Generic` attribute, but
 * reachable through `@derive(...)`, which dispatches to
 * `globalRegistry.getDerive(name)` (an attribute macro alone made
 * `@derive(Generic)` report "Unknown derive").
 *
 * Deliberately has no `module`: the registry's module-scoped index keys on
 * `module + name`, and this must not displace the `@Generic` attribute macro
 * registered under the same name.
 */
export const genericDeriveMacro = defineDeriveMacro({
  name: "Generic",
  description: "Derive Generic instance for structural programming",
  expand(
    ctx: MacroContext,
    target: ts.InterfaceDeclaration | ts.ClassDeclaration | ts.TypeAliasDeclaration
  ): ts.Statement[] {
    return expandGeneric(ctx, target);
  },
});

/** Shared expansion: the statements that follow the target declaration. */
function expandGeneric(
  ctx: MacroContext,
  target: ts.InterfaceDeclaration | ts.ClassDeclaration | ts.TypeAliasDeclaration
): ts.Statement[] {
  const typeName = target.name?.text ?? "Anonymous";

  // Check if this is a sum type (discriminated union)
  if (ts.isTypeAliasDeclaration(target)) {
    const sumInfo = tryExtractSumType(ctx, target);
    if (sumInfo) {
      return expandGenericForSumType(ctx, target, typeName, sumInfo);
    }
  }

  // Product type (interface, class, or non-union type alias)
  return expandGenericForProductType(ctx, target, typeName);
}

/**
 * Build the runtime statement for a Generic instance:
 *
 *   const genericPoint = { to: (value: Point): Point => value, from: (rep: Point): Point => rep };
 *
 * The structural metadata is registered at COMPILE time (genericMetaRegistry),
 * which is what derivation consumes. The emitted code intentionally does not
 * call `registerGeneric`/`registerGenericMeta`: those live in
 * `@typesugar/macros` (which loads the TypeScript compiler), the call sites
 * were emitted without an import (ReferenceError at module load), and
 * importing the macro package into user runtime code is not acceptable.
 * Code that wants a runtime registry entry calls `registerGeneric` itself.
 */
function buildGenericInstanceStatements(
  factory: ts.NodeFactory,
  typeName: string
): { statements: ts.Statement[]; instanceName: string } {
  const instanceName = `generic${typeName}`;
  const typeRef = () => factory.createTypeReferenceNode(typeName);
  const identity = (param: string) =>
    factory.createArrowFunction(
      undefined,
      undefined,
      [factory.createParameterDeclaration(undefined, undefined, param, undefined, typeRef())],
      typeRef(),
      factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
      factory.createIdentifier(param)
    );

  const constDecl = factory.createVariableStatement(
    undefined,
    factory.createVariableDeclarationList(
      [
        factory.createVariableDeclaration(
          instanceName,
          undefined,
          undefined,
          factory.createObjectLiteralExpression(
            [
              factory.createPropertyAssignment("to", identity("value")),
              factory.createPropertyAssignment("from", identity("rep")),
            ],
            true
          )
        ),
      ],
      ts.NodeFlags.Const
    )
  );

  return { statements: [constDecl], instanceName };
}

/**
 * Expand @derive(Generic) for a product type (interface, class, record).
 * Generates zero-cost identity conversion with metadata registration.
 */
function expandGenericForProductType(
  ctx: MacroContext,
  target: ts.InterfaceDeclaration | ts.ClassDeclaration | ts.TypeAliasDeclaration,
  typeName: string
): ts.Statement[] {
  const type = ctx.typeChecker.getTypeAtLocation(target);
  const properties = ctx.typeChecker.getPropertiesOfType(type);

  const fieldNames: string[] = [];
  const fieldTypes: string[] = [];

  for (const prop of properties) {
    fieldNames.push(prop.name);
    const decls = prop.getDeclarations();
    if (decls && decls.length > 0) {
      const propType = ctx.typeChecker.getTypeOfSymbolAtLocation(prop, decls[0]);
      fieldTypes.push(ctx.typeChecker.typeToString(propType));
    } else {
      fieldTypes.push("unknown");
    }
  }

  const factory = ctx.factory;

  const { statements } = buildGenericInstanceStatements(factory, typeName);

  // Also register metadata at compile time for immediate use
  genericMetaRegistry.set(typeName, {
    kind: "product",
    fieldNames,
    fieldTypes,
  });

  return statements;
}

/**
 * Expand @derive(Generic) for a sum type (discriminated union).
 * Generates zero-cost identity conversion - native union stays native.
 */
function expandGenericForSumType(
  ctx: MacroContext,
  target: ts.TypeAliasDeclaration,
  typeName: string,
  sumInfo: {
    discriminant: string;
    variants: Array<{ tag: string; typeName: string }>;
  }
): ts.Statement[] {
  // Get variant field information for each variant
  const variantMeta: Array<{
    tag: string;
    typeName: string;
    fieldNames: string[];
    fieldTypes: string[];
  }> = [];

  if (ts.isUnionTypeNode(target.type)) {
    for (const member of target.type.types) {
      if (!ts.isTypeReferenceNode(member)) continue;

      const variantTypeName = member.typeName.getText();
      const variantInfo = sumInfo.variants.find((v) => v.typeName === variantTypeName);
      if (!variantInfo) continue;

      const memberType = ctx.typeChecker.getTypeFromTypeNode(member);
      const fieldNames: string[] = [];
      const fieldTypes: string[] = [];

      try {
        const props = ctx.typeChecker.getPropertiesOfType(memberType);
        for (const prop of props) {
          // Skip the discriminant field
          if (prop.name === sumInfo.discriminant) continue;

          fieldNames.push(prop.name);
          const decls = prop.getDeclarations();
          if (decls && decls.length > 0) {
            const propType = ctx.typeChecker.getTypeOfSymbolAtLocation(prop, decls[0]);
            fieldTypes.push(ctx.typeChecker.typeToString(propType));
          } else {
            fieldTypes.push("unknown");
          }
        }
      } catch {
        // Skip if we can't get properties
      }

      variantMeta.push({
        tag: variantInfo.tag,
        typeName: variantTypeName,
        fieldNames,
        fieldTypes,
      });
    }
  }

  const factory = ctx.factory;

  const { statements } = buildGenericInstanceStatements(factory, typeName);

  // Also register metadata at compile time for immediate use
  genericMetaRegistry.set(typeName, {
    kind: "sum",
    discriminant: sumInfo.discriminant,
    variants: sumInfo.variants,
  });

  return statements;
}

// ============================================================================
// Generic-based Show/Eq/etc derivation
// ============================================================================

/**
 * Read field `i` (named `name`) out of a generic representation.
 *
 * `@Generic` / `@derive(Generic)` products use the zero-cost IDENTITY
 * representation (the value itself), while hand-written instances may return
 * a `Product` (`{ _tag: "Product", fields: [...] }`). Support both, rather than
 * assuming `rep.fields` exists (which threw on every identity instance).
 */
function repField(rep: unknown, i: number, name: string | undefined): unknown {
  if (
    rep !== null &&
    typeof rep === "object" &&
    (rep as { _tag?: unknown })._tag === "Product" &&
    Array.isArray((rep as { fields?: unknown }).fields)
  ) {
    return (rep as { fields: unknown[] }).fields[i];
  }
  if (name === undefined) {
    throw new Error(
      `Generic representation is not a Product and no field names are known for field #${i}`
    );
  }
  return (rep as Record<string, unknown>)[name];
}

/**
 * Create a Show instance for any type with a Generic instance.
 *
 * This is the "derive once" pattern - one function works for all types!
 */
export function deriveShowViaGeneric<T>(
  typeName: string,
  fieldShows: { show: (a: unknown) => string }[],
  fieldNames: string[]
): { show: (a: T) => string } {
  const gen = getGeneric<T, unknown>(typeName);
  if (!gen) {
    throw new Error(`No Generic instance for ${typeName}`);
  }

  return {
    show: (a: T): string => {
      const rep = gen.to(a);
      const parts = fieldNames.map(
        (name, i) => `${name} = ${fieldShows[i].show(repField(rep, i, name))}`
      );
      return `${typeName}(${parts.join(", ")})`;
    },
  };
}

/**
 * Create an Eq instance for any type with a Generic instance.
 *
 * For an identity (non-`Product`) representation the field names come from
 * `fieldNames`, else from the compile-time Generic metadata for `typeName`.
 */
export function deriveEqViaGeneric<T>(
  typeName: string,
  fieldEqs: { eq: (a: unknown, b: unknown) => boolean }[],
  fieldNames?: string[]
): { eq: (a: T, b: T) => boolean } {
  const gen = getGeneric<T, unknown>(typeName);
  if (!gen) {
    throw new Error(`No Generic instance for ${typeName}`);
  }
  const names = () => fieldNames ?? genericMetaRegistry.get(typeName)?.fieldNames;

  return {
    eq: (a: T, b: T): boolean => {
      const repA = gen.to(a);
      const repB = gen.to(b);
      const n = names();
      for (let i = 0; i < fieldEqs.length; i++) {
        if (!fieldEqs[i].eq(repField(repA, i, n?.[i]), repField(repB, i, n?.[i]))) {
          return false;
        }
      }
      return true;
    },
  };
}

// ============================================================================
// Register macros
// ============================================================================

globalRegistry.register(genericDerive);
globalRegistry.register(genericDeriveMacro);

// All exports are inline (export function, export type, export const)
