/**
 * Typeclass Instances for @typesugar/fp Data Types
 *
 * This module provides concrete typeclass instances (Functor, Monad, Foldable,
 * Traverse, etc.) for all @typesugar/fp data types, using the zero-cost HKT system.
 *
 * ## Zero-Cost Option
 *
 * Option<A> is now represented as `A | null` at runtime:
 * - Some(42) → 42
 * - None → null
 * - No wrapper objects, no tags, truly zero-cost
 *
 * ## HKT and Type Safety
 *
 * TypeScript has a recursive type instantiation limit that triggers when
 * evaluating `Monad<OptionF>`. To work around this while keeping instances
 * type-safe, we use concrete type annotations instead of HKT-parameterized
 * types.
 *
 * The types are manually expanded:
 * - `Kind<OptionF, A>` → `Option<A>`
 * - `Kind<ArrayF, A>` → `Array<A>`
 *
 * This gives us full type safety without hitting TypeScript's limits.
 *
 * ## Usage
 *
 * ```typescript
 * import { optionMonad, arrayMonad } from "./instances.js";
 *
 * // Generic function
 * function double<F>(F: Monad<F>, fa: Kind<F, number>): Kind<F, number> {
 *   return F.map(fa, x => x * 2);
 * }
 *
 * // Passing a known dictionary auto-specializes the call at compile time —
 * // no annotation needed. The dictionary is eliminated entirely.
 * const doubleOption = double(optionMonad, someOption);
 * // Compiles to: someOption !== null ? someOption * 2 : null
 * ```
 */

import { type Acc, emptyAcc, snoc, accToArray } from "./internal/acc.js";
import type { Kind } from "./hkt.js";
import type { OptionF, ArrayF, PromiseF, EitherF } from "./hkt.js";
import type { Functor } from "./typeclasses/functor.js";
import type { Applicative } from "./typeclasses/applicative.js";
import type { Monad } from "./typeclasses/monad.js";
import { makeMonad } from "./typeclasses/monad.js";
import type { Foldable } from "./typeclasses/foldable.js";
import type { Traverse } from "./typeclasses/traverse.js";
import type { MonadError } from "./typeclasses/monad-error.js";
import type { SemigroupK, MonoidK, Alternative } from "./typeclasses/alternative.js";

import type { Option } from "./data/option.js";
// Note: With null-based Option, isSome(opt) = opt !== null, isNone(opt) = opt === null
// Some(x) = x, None = null
import type { Either } from "./data/either.js";
import { Left, Right, isLeft, isRight } from "./data/either.js";

// ============================================================================
// Expanded Type Aliases (to avoid HKT recursion)
// ============================================================================

/**
 * Concrete Functor type for Option (expanded from Functor<OptionF>)
 */
type OptionFunctor = {
  readonly map: <A, B>(fa: Option<A>, f: (a: A) => B) => Option<B>;
};

/**
 * Concrete Monad type for Option (expanded from Monad<OptionF>)
 */
type OptionMonad = {
  readonly map: <A, B>(fa: Option<A>, f: (a: A) => B) => Option<B>;
  readonly flatMap: <A, B>(fa: Option<A>, f: (a: A) => Option<B>) => Option<B>;
  readonly pure: <A>(a: A) => Option<A>;
  readonly ap: <A, B>(fab: Option<(a: A) => B>, fa: Option<A>) => Option<B>;
};

/**
 * Concrete Foldable type for Option (expanded from Foldable<OptionF>)
 */
type OptionFoldable = {
  readonly foldLeft: <A, B>(fa: Option<A>, b: B, f: (b: B, a: A) => B) => B;
  readonly foldRight: <A, B>(fa: Option<A>, b: B, f: (a: A, b: B) => B) => B;
};

/**
 * Concrete Traverse type for Option (expanded from Traverse<OptionF>)
 */
type OptionTraverse = OptionFunctor &
  OptionFoldable & {
    readonly traverse: <G>(
      G: Applicative<G>
    ) => <A, B>(fa: Option<A>, f: (a: A) => Kind<G, B>) => Kind<G, Option<B>>;
  };

/**
 * Concrete SemigroupK type for Option
 */
type OptionSemigroupK = {
  readonly combineK: <A>(x: Option<A>, y: Option<A>) => Option<A>;
};

/**
 * Concrete MonoidK type for Option
 */
type OptionMonoidK = OptionSemigroupK & {
  readonly emptyK: <A>() => Option<A>;
};

/**
 * Concrete Alternative type for Option
 */
type OptionAlternative = OptionMonad & OptionMonoidK;

/**
 * Concrete Functor type for Array (expanded from Functor<ArrayF>)
 */
type ArrayFunctor = {
  readonly map: <A, B>(fa: A[], f: (a: A) => B) => B[];
};

/**
 * Concrete Monad type for Array (expanded from Monad<ArrayF>)
 */
type ArrayMonad = {
  readonly map: <A, B>(fa: A[], f: (a: A) => B) => B[];
  readonly flatMap: <A, B>(fa: A[], f: (a: A) => B[]) => B[];
  readonly pure: <A>(a: A) => A[];
  readonly ap: <A, B>(fab: ((a: A) => B)[], fa: A[]) => B[];
};

/**
 * Concrete Foldable type for Array
 */
type ArrayFoldable = {
  readonly foldLeft: <A, B>(fa: A[], b: B, f: (b: B, a: A) => B) => B;
  readonly foldRight: <A, B>(fa: A[], b: B, f: (a: A, b: B) => B) => B;
};

/**
 * Concrete Traverse type for Array
 */
type ArrayTraverse = ArrayFunctor &
  ArrayFoldable & {
    readonly traverse: <G>(
      G: Applicative<G>
    ) => <A, B>(fa: A[], f: (a: A) => Kind<G, B>) => Kind<G, B[]>;
  };

/**
 * Concrete SemigroupK type for Array
 */
type ArraySemigroupK = {
  readonly combineK: <A>(x: A[], y: A[]) => A[];
};

/**
 * Concrete MonoidK type for Array
 */
type ArrayMonoidK = ArraySemigroupK & {
  readonly emptyK: <A>() => A[];
};

/**
 * Concrete Alternative type for Array
 */
type ArrayAlternative = ArrayMonad & ArrayMonoidK;

/**
 * Concrete Functor type for Promise (expanded from Functor<PromiseF>)
 */
type PromiseFunctor = {
  readonly map: <A, B>(fa: Promise<A>, f: (a: A) => B) => Promise<B>;
};

/**
 * Concrete Monad type for Promise (expanded from Monad<PromiseF>)
 */
type PromiseMonad = {
  readonly map: <A, B>(fa: Promise<A>, f: (a: A) => B) => Promise<B>;
  readonly flatMap: <A, B>(fa: Promise<A>, f: (a: A) => Promise<B>) => Promise<B>;
  readonly pure: <A>(a: A) => Promise<A>;
  readonly ap: <A, B>(fab: Promise<(a: A) => B>, fa: Promise<A>) => Promise<B>;
};

/**
 * Concrete Functor type for Either<E, _> (expanded from Functor<EitherF<E>>)
 * Parameterized by error type E.
 */
type EitherFunctor<E> = {
  readonly map: <A, B>(fa: Either<E, A>, f: (a: A) => B) => Either<E, B>;
};

/**
 * Concrete Monad type for Either<E, _> (expanded from Monad<EitherF<E>>)
 */
type EitherMonad<E> = {
  readonly map: <A, B>(fa: Either<E, A>, f: (a: A) => B) => Either<E, B>;
  readonly flatMap: <A, B>(fa: Either<E, A>, f: (a: A) => Either<E, B>) => Either<E, B>;
  readonly pure: <A>(a: A) => Either<E, A>;
  readonly ap: <A, B>(fab: Either<E, (a: A) => B>, fa: Either<E, A>) => Either<E, B>;
};

/**
 * Concrete MonadError type for Either<E, _> (expanded from MonadError<EitherF<E>, E>)
 */
type EitherMonadError<E> = EitherMonad<E> & {
  readonly raiseError: <A>(e: E) => Either<E, A>;
  readonly handleErrorWith: <A>(fa: Either<E, A>, f: (e: E) => Either<E, A>) => Either<E, A>;
};

/**
 * Concrete Foldable type for Either<E, _>
 */
type EitherFoldable<E> = {
  readonly foldLeft: <A, B>(fa: Either<E, A>, b: B, f: (b: B, a: A) => B) => B;
  readonly foldRight: <A, B>(fa: Either<E, A>, b: B, f: (a: A, b: B) => B) => B;
};

/**
 * Concrete Traverse type for Either<E, _>
 */
type EitherTraverse<E> = EitherFunctor<E> &
  EitherFoldable<E> & {
    readonly traverse: <G>(
      G: Applicative<G>
    ) => <A, B>(fa: Either<E, A>, f: (a: A) => Kind<G, B>) => Kind<G, Either<E, B>>;
  };

/**
 * Concrete SemigroupK type for Either<E, _>
 */
type EitherSemigroupK<E> = {
  readonly combineK: <A>(x: Either<E, A>, y: Either<E, A>) => Either<E, A>;
};

// ============================================================================
// Option Instances (Zero-Cost: Option<A> = A | null)
// ============================================================================

/**
 * Functor instance for Option
 *
 * With null-based Option, Some(x) is just x and None is null.
 * Uses concrete expanded types to avoid TypeScript's HKT recursion.
 */
/** @impl Functor<OptionF> */
export const optionFunctor: OptionFunctor = {
  map: <A, B>(fa: Option<A>, f: (a: A) => B): Option<B> =>
    (fa as any) !== null ? (f(fa as any) as any) : (null as any),
};
/**
 * Monad instance for Option
 *
 * Uses concrete expanded types (OptionMonad) instead of Monad<OptionF>
 * to avoid TypeScript's recursive type instantiation limit.
 */
/** @impl Monad<OptionF> */
export const optionMonad: OptionMonad = {
  map: optionFunctor.map,
  flatMap: <A, B>(fa: Option<A>, f: (a: A) => Option<B>): Option<B> =>
    (fa as any) !== null ? f(fa as any) : (null as any),
  pure: <A>(a: A): Option<A> => a as any,
  ap: <A, B>(fab: Option<(a: A) => B>, fa: Option<A>): Option<B> =>
    (fab as any) !== null && (fa as any) !== null
      ? ((fab as any)(fa as any) as any)
      : (null as any),
};
/**
 * Foldable instance for Option
 */
/** @impl Foldable<OptionF> */
export const optionFoldable: OptionFoldable = {
  foldLeft: <A, B>(fa: Option<A>, b: B, f: (b: B, a: A) => B): B =>
    (fa as any) !== null ? f(b, fa as any) : b,
  foldRight: <A, B>(fa: Option<A>, b: B, f: (a: A, b: B) => B): B =>
    (fa as any) !== null ? f(fa as any, b) : b,
};
/**
 * Traverse instance for Option
 */
/** @impl Traverse<OptionF> */
export const optionTraverse: OptionTraverse = {
  ...optionFunctor,
  ...optionFoldable,
  traverse:
    <G>(G: Applicative<G>) =>
    <A, B>(fa: Option<A>, f: (a: A) => Kind<G, B>): Kind<G, Option<B>> => {
      if ((fa as any) !== null) {
        return G.map(f(fa as any), (b: B) => b as any);
      }
      return G.pure(null as any);
    },
};
/**
 * SemigroupK instance for Option (first Some wins)
 */
/** @impl SemigroupK<OptionF> */
export const optionSemigroupK: OptionSemigroupK = {
  combineK: <A>(x: Option<A>, y: Option<A>): Option<A> => ((x as any) !== null ? x : y),
};
/**
 * MonoidK instance for Option
 */
/** @impl MonoidK<OptionF> */
export const optionMonoidK: OptionMonoidK = {
  ...optionSemigroupK,
  emptyK: <A>(): Option<A> => null as any,
};
/**
 * Alternative instance for Option
 */
/** @impl Alternative<OptionF> */
export const optionAlternative: OptionAlternative = {
  ...optionMonad,
  ...optionMonoidK,
};
// ============================================================================
// Array Instances
// ============================================================================

/**
 * Functor instance for Array
 */
/** @impl Functor<ArrayF> */
export const arrayFunctor: ArrayFunctor = {
  map: <A, B>(fa: A[], f: (a: A) => B): B[] => fa.map(f),
};
/**
 * Monad instance for Array
 */
/** @impl Monad<ArrayF> */
export const arrayMonad: ArrayMonad = {
  map: arrayFunctor.map,
  flatMap: <A, B>(fa: A[], f: (a: A) => B[]): B[] => fa.flatMap(f),
  pure: <A>(a: A): A[] => [a],
  ap: <A, B>(fab: ((a: A) => B)[], fa: A[]): B[] => fab.flatMap((f) => fa.map(f)),
};
/**
 * Foldable instance for Array
 */
/** @impl Foldable<ArrayF> */
export const arrayFoldable: ArrayFoldable = {
  foldLeft: <A, B>(fa: A[], b: B, f: (b: B, a: A) => B): B => fa.reduce(f, b),
  foldRight: <A, B>(fa: A[], b: B, f: (a: A, b: B) => B): B =>
    fa.reduceRight((acc, a) => f(a, acc), b),
};
/**
 * Traverse instance for Array
 */
/** @impl Traverse<ArrayF> */
export const arrayTraverse: ArrayTraverse = {
  ...arrayFunctor,
  ...arrayFoldable,
  traverse:
    <G>(G: Applicative<G>) =>
    <A, B>(fa: A[], f: (a: A) => Kind<G, B>): Kind<G, B[]> =>
      G.map(
        fa.reduce(
          (acc: Kind<G, Acc<B>>, a: A) =>
            G.ap(
              G.map(acc, (bs: Acc<B>) => (b: B) => snoc(bs, b)),
              f(a)
            ),
          G.pure(emptyAcc as Acc<B>)
        ),
        accToArray
      ),
};
/**
 * SemigroupK instance for Array
 */
/** @impl SemigroupK<ArrayF> */
export const arraySemigroupK: ArraySemigroupK = {
  combineK: <A>(x: A[], y: A[]): A[] => [...x, ...y],
};
/**
 * MonoidK instance for Array
 */
/** @impl MonoidK<ArrayF> */
export const arrayMonoidK: ArrayMonoidK = {
  ...arraySemigroupK,
  emptyK: <A>(): A[] => [],
};
/**
 * Alternative instance for Array
 */
/** @impl Alternative<ArrayF> */
export const arrayAlternative: ArrayAlternative = {
  ...arrayMonad,
  ...arrayMonoidK,
};
// ============================================================================
// Promise Instances
// ============================================================================

/**
 * Functor instance for Promise
 */
/** @impl Functor<PromiseF> */
export const promiseFunctor: PromiseFunctor = {
  map: <A, B>(fa: Promise<A>, f: (a: A) => B): Promise<B> => fa.then(f),
};
/**
 * Monad instance for Promise
 */
/** @impl Monad<PromiseF> */
export const promiseMonad: PromiseMonad = {
  map: promiseFunctor.map,
  flatMap: <A, B>(fa: Promise<A>, f: (a: A) => Promise<B>): Promise<B> => fa.then(f),
  pure: <A>(a: A): Promise<A> => Promise.resolve(a),
  ap: <A, B>(fab: Promise<(a: A) => B>, fa: Promise<A>): Promise<B> =>
    fab.then((f) => fa.then((a) => f(a))),
};
// ============================================================================
// Either Instances
// ============================================================================

/**
 * Create a Functor for Either with a fixed error type E.
 * Uses concrete expanded types to avoid TypeScript's HKT recursion.
 */
export function eitherFunctor<E>(): EitherFunctor<E> {
  return {
    map: <A, B>(fa: Either<E, A>, f: (a: A) => B): Either<E, B> =>
      isRight(fa) ? Right(f(fa.right)) : (fa as Left<E, B>),
  };
}

/**
 * Create a Monad for Either with a fixed error type E.
 */
export function eitherMonad<E>(): EitherMonad<E> {
  const functor = eitherFunctor<E>();
  return {
    map: functor.map,
    flatMap: <A, B>(fa: Either<E, A>, f: (a: A) => Either<E, B>): Either<E, B> =>
      isRight(fa) ? f(fa.right) : (fa as Left<E, B>),
    pure: <A>(a: A): Either<E, A> => Right(a),
    ap: <A, B>(fab: Either<E, (a: A) => B>, fa: Either<E, A>): Either<E, B> => {
      if (isLeft(fab)) return fab as Left<E, B>;
      if (isLeft(fa)) return fa as Left<E, B>;
      return Right(fab.right(fa.right));
    },
  };
}

/**
 * Create a MonadError for Either with a fixed error type E.
 */
export function eitherMonadError<E>(): EitherMonadError<E> {
  const monad = eitherMonad<E>();
  return {
    ...monad,
    raiseError: <A>(e: E): Either<E, A> => Left(e),
    handleErrorWith: <A>(fa: Either<E, A>, f: (e: E) => Either<E, A>): Either<E, A> =>
      isLeft(fa) ? f(fa.left!) : fa,
  };
}

/**
 * Create a Foldable for Either with a fixed error type E.
 */
export function eitherFoldable<E>(): EitherFoldable<E> {
  return {
    foldLeft: <A, B>(fa: Either<E, A>, b: B, f: (b: B, a: A) => B): B =>
      isRight(fa) ? f(b, fa.right) : b,
    foldRight: <A, B>(fa: Either<E, A>, b: B, f: (a: A, b: B) => B): B =>
      isRight(fa) ? f(fa.right, b) : b,
  };
}

/**
 * Create a Traverse for Either with a fixed error type E.
 */
export function eitherTraverse<E>(): EitherTraverse<E> {
  const functor = eitherFunctor<E>();
  const foldable = eitherFoldable<E>();
  return {
    ...functor,
    ...foldable,
    traverse:
      <G>(G: Applicative<G>) =>
      <A, B>(fa: Either<E, A>, f: (a: A) => Kind<G, B>): Kind<G, Either<E, B>> => {
        if (isRight(fa)) {
          return G.map(f(fa.right), (b: B) => Right(b));
        }
        return G.pure(fa as Left<E, B>);
      },
  };
}

/**
 * Create a SemigroupK for Either with a fixed error type E.
 */
export function eitherSemigroupK<E>(): EitherSemigroupK<E> {
  return {
    combineK: <A>(x: Either<E, A>, y: Either<E, A>): Either<E, A> => (isRight(x) ? x : y),
  };
}

// ============================================================================
// Specialization templates
// ============================================================================
// These templates document how the transformer auto-specializes (inlines)
// these typeclass operations at compile time — see
// packages/macros/src/specialize.ts and tryExtractInstanceFromSource, which
// read these instances' own source rather than a separate registration step.
//
// Option templates (zero-cost null-based):
//   optionFunctor.map:   '(fa, f) => fa !== null ? f(fa) : null'
//   optionMonad.pure:    '(a) => a'
//   optionMonad.flatMap: '(fa, f) => fa !== null ? f(fa) : null'
//   optionMonad.ap:      '(fab, fa) => fab !== null && fa !== null ? fab(fa) : null'
//
// Array templates:
//   arrayFunctor.map:    '(fa, f) => fa.map(f)'
//   arrayMonad.pure:     '(a) => [a]'
//   arrayMonad.flatMap:  '(fa, f) => fa.flatMap(f)'
//
// Either templates:
//   eitherFunctor.map:   '(fa, f) => fa._tag === "Right" ? { _tag: "Right", right: f(fa.right) } : fa'
//   eitherMonad.pure:    '(a) => ({ _tag: "Right", right: a })'
//   eitherMonad.flatMap: '(fa, f) => fa._tag === "Right" ? f(fa.right) : fa'

// ============================================================================
// @typesugar/std FlatMap Typeclass Bridge
// ============================================================================
// FlatMap instances for @typesugar/fp types, compatible with @typesugar/std's FlatMap typeclass.
// These can be registered with @typesugar/std when needed for let:/yield: macro support.

import type { List } from "./data/list.js";
import { map as listMap, flatMap as listFlatMap } from "./data/list.js";
import type { IO } from "./io/io.js";
import { IO as IONamespace } from "./io/io.js";
import type { Validated } from "./data/validated.js";
import { map as validatedMap, andThen as validatedFlatMap } from "./data/validated.js";

/**
 * FlatMap instance for Option.
 * Option<A> = A | null (zero-cost representation)
 */
/**
 * @impl FlatMap<OptionF>
 * @do-methods bind=flatMap map=map orElse=orElse style=static receiver=flatMapOption
 * @do-instance-module @typesugar/fp
 */
export const flatMapOption = {
  _tag: "Option" as const,
  map: <A, B>(fa: Option<A>, f: (a: A) => B): Option<B> =>
    (fa as any) !== null ? (f(fa as any) as any) : (null as any),
  flatMap: <A, B>(fa: Option<A>, f: (a: A) => Option<B>): Option<B> =>
    (fa as any) !== null ? f(fa as any) : (null as any),
  /** `x << fa || alt` / `?? alt` in `let:`: `fa` if it is Some, else `f()`. */
  orElse: <A>(fa: Option<A>, f: (none: null) => Option<A>): Option<A> =>
    (fa as any) !== null ? fa : f(null),
};
/**
 * Create FlatMap instance for Either with a fixed error type E.
 */
export function flatMapEither<E>() {
  return {
    _tag: "Either" as const,
    map: <A, B>(fa: Either<E, A>, f: (a: A) => B): Either<E, B> =>
      isRight(fa) ? Right(f(fa.right)) : (fa as Left<E, B>),
    flatMap: <A, B>(fa: Either<E, A>, f: (a: A) => Either<E, B>): Either<E, B> =>
      isRight(fa) ? f(fa.right) : (fa as Left<E, B>),
  };
}

/**
 * FlatMap instance for Either, usable by do-notation scope resolution
 * (PEP-052). The factory above fixes `E` at the TYPE level, but the returned
 * dictionary is uniform in `E` at runtime (`map`/`flatMap` only touch the
 * `Right` branch), so this single scanner-visible const serves every error
 * type — the factory remains for callers who want `E` pinned in the types.
 */
/**
 * @impl FlatMap<EitherF>
 * @do-methods bind=flatMap map=map orElse=orElse style=static receiver=flatMapEitherInstance
 * @do-instance-module @typesugar/fp
 */
export const flatMapEitherInstance = {
  ...flatMapEither<unknown>(),
  /** `x << fa || alt` / `?? alt` in `let:`: `fa` if it is Right, else `f(left)`. */
  orElse: <E, A, E2>(fa: Either<E, A>, f: (e: E) => Either<E2, A>): Either<E2, A> =>
    isRight(fa) ? (fa as unknown as Either<E2, A>) : f((fa as Left<E, A>).left),
};
/**
 * FlatMap instance for IO.
 */
/**
 * @impl FlatMap<IOF>
 * @do-methods bind=flatMap map=map style=static receiver=flatMapIO
 * @do-instance-module @typesugar/fp
 */
export const flatMapIO = {
  _tag: "IO" as const,
  map: <A, B>(fa: IO<A>, f: (a: A) => B): IO<B> => IONamespace.map(fa, f),
  flatMap: <A, B>(fa: IO<A>, f: (a: A) => IO<B>): IO<B> => IONamespace.flatMap(fa, f),
};
/**
 * FlatMap instance for List.
 */
/**
 * @impl FlatMap<ListF>
 * @do-methods bind=flatMap map=map style=static receiver=flatMapList
 * @do-instance-module @typesugar/fp
 */
export const flatMapList = {
  _tag: "List" as const,
  map: <A, B>(fa: List<A>, f: (a: A) => B): List<B> => listMap(fa, f),
  flatMap: <A, B>(fa: List<A>, f: (a: A) => List<B>): List<B> => listFlatMap(fa, f),
};
/**
 * Create FlatMap instance for Validated with a fixed error type E.
 *
 * Note: This uses `andThen` which short-circuits on first error,
 * unlike Validated's applicative operations that accumulate errors.
 * Use the Applicative instance for error accumulation.
 */
export function flatMapValidated<E>() {
  return {
    _tag: "Validated" as const,
    map: <A, B>(fa: Validated<E, A>, f: (a: A) => B): Validated<E, B> => validatedMap(fa, f),
    flatMap: <A, B>(fa: Validated<E, A>, f: (a: A) => Validated<E, B>): Validated<E, B> =>
      validatedFlatMap(fa, f),
  };
}

/**
 * All FlatMap instances for @typesugar/fp types, keyed by type-constructor name.
 * The let:/yield: macro resolves these by scope (PEP-052) — importing
 * @typesugar/fp brings the @impl-tagged instances above into scope.
 */
export const fpFlatMapInstances = {
  Option: flatMapOption,
  Either: flatMapEither<unknown>(),
  IO: flatMapIO,
  List: flatMapList,
  Validated: flatMapValidated<unknown>(),
} as const;

// ============================================================================
// = implicit() Examples
// ============================================================================
// These functions demonstrate patterns designed for use with the = implicit()
// default parameter pattern. When = implicit() is used, the transformer
// auto-fills typeclass parameters at call sites based on the types involved.

/**
 * Traverse an array with an effect-producing function.
 *
 * This is the canonical = implicit() example: with = implicit() on the
 * G (Applicative) parameter, it is auto-filled based on the return type of f.
 *
 * @example
 * Without = implicit():
 * ```ts
 * // Must pass Applicative explicitly
 * const result = traverseArray(optionApplicative)([1, 2, 3], n => Some(n * 2));
 * ```
 *
 * With = implicit() (when transformer is active):
 * ```ts
 * function traverseArray<G, A, B>(xs: A[], f: (a: A) => Kind<G, B>, G: Applicative<G> = implicit()): Kind<G, B[]>
 *
 * // G is auto-filled from return type of f
 * const result = traverseArray([1, 2, 3], n => Some(n * 2));
 * // Transforms to: traverseArray([1, 2, 3], n => Some(n * 2), optionApplicative)
 * ```
 *
 * @param G - The Applicative instance for the effect type
 */
export function traverseArray<G>(G: Applicative<G>) {
  return <A, B>(xs: A[], f: (a: A) => Kind<G, B>): Kind<G, B[]> => arrayTraverse.traverse(G)(xs, f);
}

/**
 * Sequence an array of effects into an effect of array.
 *
 * @example
 * Without = implicit():
 * ```ts
 * const result = sequenceArray(optionApplicative)([Some(1), Some(2), Some(3)]);
 * // → Some([1, 2, 3])
 * ```
 *
 * With = implicit():
 * ```ts
 * function sequenceArray<G, A>(xs: Kind<G, A>[], G: Applicative<G> = implicit()): Kind<G, A[]>
 *
 * const result = sequenceArray([Some(1), Some(2), Some(3)]);
 * // Transforms to: sequenceArray([Some(1), Some(2), Some(3)], optionApplicative)
 * ```
 */
export function sequenceArray<G>(G: Applicative<G>) {
  return <A>(xs: Kind<G, A>[]): Kind<G, A[]> => arrayTraverse.traverse(G)(xs, (x) => x);
}

/**
 * Map over a value in a Functor context.
 *
 * @example
 * With = implicit():
 * ```ts
 * function fmap<F, A, B>(fa: Kind<F, A>, f: (a: A) => B, F: Functor<F> = implicit()): Kind<F, B>
 *
 * const result = fmap(Some(1), n => n * 2);
 * // Transforms to: fmap(Some(1), n => n * 2, optionFunctor) → 2
 * ```
 */
export function fmap<F>(F: Functor<F>) {
  return <A, B>(fa: Kind<F, A>, f: (a: A) => B): Kind<F, B> => F.map(fa, f);
}

/**
 * FlatMap (bind) over a value in a Monad context.
 *
 * @example
 * With = implicit():
 * ```ts
 * function bind<F, A, B>(fa: Kind<F, A>, f: (a: A) => Kind<F, B>, F: Monad<F> = implicit()): Kind<F, B>
 *
 * const result = bind(Some(1), n => n > 0 ? Some(n * 2) : None);
 * // Transforms to: bind(Some(1), f, optionMonad) → 2
 * ```
 */
export function bind<F>(F: Monad<F>) {
  return <A, B>(fa: Kind<F, A>, f: (a: A) => Kind<F, B>): Kind<F, B> => F.flatMap(fa, f);
}

/**
 * Apply a function in a context to a value in a context.
 *
 * @example
 * With = implicit():
 * ```ts
 * function ap<F, A, B>(ff: Kind<F, (a: A) => B>, fa: Kind<F, A>, F: Applicative<F> = implicit()): Kind<F, B>
 *
 * const add = (a: number) => (b: number) => a + b;
 * const result = ap(Some(add(1)), Some(2));
 * // Transforms to: ap(Some(add(1)), Some(2), optionApplicative) → 3
 * ```
 */
export function applyF<F>(F: Applicative<F>) {
  return <A, B>(ff: Kind<F, (a: A) => B>, fa: Kind<F, A>): Kind<F, B> => F.ap(ff, fa);
}

/**
 * Fold a Foldable structure to a single value.
 *
 * @example
 * With = implicit():
 * ```ts
 * function foldL<F, A, B>(fa: Kind<F, A>, b: B, f: (b: B, a: A) => B, F: Foldable<F> = implicit()): B
 *
 * const result = foldL(Some(5), 0, (acc, n) => acc + n);
 * // Transforms to: foldL(Some(5), 0, f, optionFoldable) → 5
 * ```
 */
export function foldL<F>(F: Foldable<F>) {
  return <A, B>(fa: Kind<F, A>, b: B, f: (b: B, a: A) => B): B => F.foldLeft(fa, b, f);
}
