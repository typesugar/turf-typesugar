/**
 * ApplicativeError and MonadError Typeclasses
 *
 * These extend Applicative and Monad with error handling capabilities.
 * Allows for raising and recovering from errors in a principled way.
 *
 * Laws:
 *   - raiseError(e).handleError(f) === f(e)
 *   - pure(a).handleError(f) === pure(a)
 *   - raiseError(e).flatMap(f) === raiseError(e)
 */

import type { Applicative, Apply } from "./applicative.js";
import type { Monad, FlatMap } from "./monad.js";
import type { Kind } from "../hkt.js";
// The package's real Either/Option (`{left}|{right}` and `A | null`), not a
// private `{_tag, value}` shape that no other part of @typesugar/fp produces.
import type { Either } from "../data/either.js";
import { Left, Right, isRight } from "../data/either.js";
import type { Option } from "../data/option.js";

// ============================================================================
// ApplicativeError
// ============================================================================

/**
 * ApplicativeError typeclass - Applicative with error handling
 *
 * E is the error type, F is the type constructor
 *
 * @typeclass
 */
export interface ApplicativeError<F, E> extends Applicative<F> {
  readonly raiseError: <A>(e: E) => Kind<F, A>;
  readonly handleErrorWith: <A>(fa: Kind<F, A>, f: (e: E) => Kind<F, A>) => Kind<F, A>;
}

// ============================================================================
// MonadError
// ============================================================================

/**
 * MonadError typeclass - Monad with error handling
 *
 * @typeclass
 */
export interface MonadError<F, E> extends ApplicativeError<F, E>, Monad<F> {}

// ============================================================================
// Derived Operations from ApplicativeError
// ============================================================================

/**
 * Handle errors with a pure recovery function
 */
export function handleError<F, E>(
  F: ApplicativeError<F, E>
): <A>(fa: Kind<F, A>, f: (e: E) => A) => Kind<F, A> {
  return (fa, f) => F.handleErrorWith(fa, (e) => F.pure(f(e)));
}

/**
 * Recover from errors, providing a fallback value
 */
export function recover<F, E>(
  F: ApplicativeError<F, E>
): <A>(fa: Kind<F, A>, fallback: A) => Kind<F, A> {
  return (fa, fallback) => handleError(F)(fa, () => fallback);
}

/**
 * Try to recover with an optional partial function
 */
export function recoverWith<F, E>(
  F: ApplicativeError<F, E>
): <A>(fa: Kind<F, A>, pf: (e: E) => Kind<F, A> | undefined) => Kind<F, A> {
  return (fa, pf) =>
    F.handleErrorWith(fa, (e) => {
      const result = pf(e);
      return result !== undefined ? result : F.raiseError(e);
    });
}

/**
 * Convert error to Option.none, keeping success as Option.some
 */
export function attempt<F, E>(
  F: ApplicativeError<F, E>
): <A>(fa: Kind<F, A>) => Kind<F, Either<E, A>> {
  return <A>(fa: Kind<F, A>): Kind<F, Either<E, A>> =>
    F.handleErrorWith(
      F.map(fa, (a: A): Either<E, A> => Right<E, A>(a)),
      (e: E): Kind<F, Either<E, A>> => F.pure(Left<E, A>(e))
    );
}

/**
 * Lift from Either into the error context
 */
export function fromEither<F, E>(
  F: ApplicativeError<F, E>
): <A>(either: Either<E, A>) => Kind<F, A> {
  return (either) => (isRight(either) ? F.pure(either.right) : F.raiseError(either.left));
}

/**
 * Lift from Option, using provided error for None case
 */
export function fromOption<F, E>(
  F: ApplicativeError<F, E>
): <A>(option: Option<A>, error: () => E) => Kind<F, A> {
  // With null-based Option, option IS the value when it's not null
  return <A>(option: Option<A>, error: () => E): Kind<F, A> =>
    option !== null ? F.pure(option as A) : F.raiseError(error());
}

// ============================================================================
// Derived Operations from MonadError
// ============================================================================

/**
 * Ensure a condition holds, raising error if not
 */
export function ensure<F, E>(
  F: MonadError<F, E>
): <A>(fa: Kind<F, A>, error: (a: A) => E, p: (a: A) => boolean) => Kind<F, A> {
  return (fa, error, p) => F.flatMap(fa, (a) => (p(a) ? F.pure(a) : F.raiseError(error(a))));
}

/**
 * Ensure a condition holds, raising error if it does
 */
export function ensureOr<F, E>(
  F: MonadError<F, E>
): <A>(fa: Kind<F, A>, error: (a: A) => E, p: (a: A) => boolean) => Kind<F, A> {
  return (fa, error, p) => F.flatMap(fa, (a) => (p(a) ? F.raiseError(error(a)) : F.pure(a)));
}

/**
 * Re-raise an error, potentially transformed
 */
export function adaptError<F, E>(
  F: MonadError<F, E>
): <A>(fa: Kind<F, A>, f: (e: E) => E) => Kind<F, A> {
  return (fa, f) => F.handleErrorWith(fa, (e) => F.raiseError(f(e)));
}

/**
 * Try a fallback on error
 */
export function orElse<F, E>(
  F: MonadError<F, E>
): <A>(fa: Kind<F, A>, fallback: () => Kind<F, A>) => Kind<F, A> {
  return (fa, fallback) => F.handleErrorWith(fa, () => fallback());
}

/**
 * Rethrow after inspecting the error
 */
export function onError<F, E>(
  F: MonadError<F, E>
): <A>(fa: Kind<F, A>, handler: (e: E) => Kind<F, void>) => Kind<F, A> {
  return <A>(fa: Kind<F, A>, handler: (e: E) => Kind<F, void>): Kind<F, A> =>
    F.handleErrorWith(fa, (e: E) => F.flatMap(handler(e), () => F.raiseError<A>(e)));
}

// ============================================================================
// Helper Types
// ============================================================================

// ============================================================================
// Instance Creator
// ============================================================================

/**
 * Create a MonadError instance
 */
export function makeMonadError<F, E>(
  map: <A, B>(fa: Kind<F, A>, f: (a: A) => B) => Kind<F, B>,
  flatMap: <A, B>(fa: Kind<F, A>, f: (a: A) => Kind<F, B>) => Kind<F, B>,
  pure: <A>(a: A) => Kind<F, A>,
  raiseError: <A>(e: E) => Kind<F, A>,
  handleErrorWith: <A>(fa: Kind<F, A>, f: (e: E) => Kind<F, A>) => Kind<F, A>
): MonadError<F, E> {
  return {
    map,
    flatMap,
    pure,
    ap: (fab, fa) => flatMap(fab, (f) => map(fa, f)),
    raiseError,
    handleErrorWith,
  };
}
